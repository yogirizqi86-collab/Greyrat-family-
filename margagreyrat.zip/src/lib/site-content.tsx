import { useEffect, useState } from "react";

import heroBannerDefault from "@/assets/hero-banner.jpg";
import gallery1 from "@/assets/gallery-1.jpg";
import gallery2 from "@/assets/gallery-2.jpg";
import gallery3 from "@/assets/gallery-3.jpg";
import gallery4 from "@/assets/gallery-4.jpg";

export type GalleryItem = { img: string; title: string; desc: string };
export type RuleItem = { title: string; desc: string };
export type LeaderItem = { name: string; role: string; title: string };
export type StatItem = { label: string; value: string };

export type SiteContent = {
  brand: string;
  tagline: string;
  joinUrl: string;
  heroImage: string;
  aboutImage: string;
  hero: {
    eyebrow: string;
    title: string;
    subtitle: string;
    primaryCta: string;
    secondaryCta: string;
  };
  about: { title: string; body: string; stats: StatItem[] };
  gallery: GalleryItem[];
  rules: RuleItem[];
  leaders: LeaderItem[];
};

export const DEFAULTS: SiteContent = {
  brand: "Marga Greyrat",
  tagline: "House of Mages",
  joinUrl: "https://chat.whatsapp.com/GUoYJaMyLzMKSjpdHEOBao",
  heroImage: heroBannerDefault,
  aboutImage: gallery2,
  hero: {
    eyebrow: "Komunitas Editor Anime Fantasy",
    title: "Sebuah Marga untuk Para Pencipta",
    subtitle:
      "Tempat berkumpulnya editor & kreator yang dipersatukan oleh cinta pada dunia anime fantasi — sihir, petualangan, dan kisah tanpa akhir.",
    primaryCta: "Bergabung dengan Marga",
    secondaryCta: "Jelajahi Dunia",
  },
  about: {
    title: "Tentang Marga Greyrat",
    body:
      "Marga Greyrat dibentuk untuk merangkul para editor anime dari segala tingkat — dari yang baru memegang mana, hingga sage berpengalaman. Kami berbagi ilmu, kolaborasi, dan tumbuh bersama di bawah satu panji.",
    stats: [
      { label: "Anggota Aktif", value: "1,248" },
      { label: "Project Bulan Ini", value: "86" },
      { label: "Tahun Berdiri", value: "2023" },
    ],
  },
  gallery: [
    { img: gallery1, title: "Arc Sihir Awal", desc: "Karya pemula yang penuh potensi" },
    { img: gallery2, title: "Negeri Buena Village", desc: "Kolaborasi senja para anggota" },
    { img: gallery3, title: "Grimoire Komunitas", desc: "Kumpulan preset & tutorial" },
    { img: gallery4, title: "Festival Sakura", desc: "Event tahunan marga" },
  ],
  rules: [
    { title: "Hormati Setiap Anggota", desc: "Tidak ada toxic, diskriminasi, atau drama. Marga ini rumah bersama." },
    { title: "Hargai Karya Orang Lain", desc: "Dilarang reupload tanpa izin. Selalu sertakan credit." },
    { title: "Bagikan, Jangan Tahan", desc: "Saling berbagi preset, knowledge, dan tips. Kita tumbuh bersama." },
    { title: "Bebas Promosi Berlebihan", desc: "Spam link & promosi liar akan dimoderasi tanpa peringatan." },
    { title: "Konten Sesuai Tema", desc: "Fokus pada anime, editing, dan dunia fantasi. Off-topic seperlunya." },
    { title: "Aktif & Suportif", desc: "Hadir di event, beri feedback, ramaikan diskusi marga." },
  ],
  leaders: [
    { name: "Rudeus", role: "Kepala Marga", title: "Sage of the Seven Stars" },
    { name: "Eris", role: "Pelatih Combat", title: "Sword Saint" },
    { name: "Roxy", role: "Mentor Sihir", title: "Master of Waters" },
    { name: "Sylphiette", role: "Koordinator Event", title: "Wind Caller" },
  ],
};

const KEY = "marga-site-content-v1";
const EVT = "marga-site-content-changed";

export function loadContent(): SiteContent {
  if (typeof window === "undefined") return DEFAULTS;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULTS;
    const parsed = JSON.parse(raw);
    return { ...DEFAULTS, ...parsed };
  } catch {
    return DEFAULTS;
  }
}

export function saveContent(c: SiteContent) {
  try {
    localStorage.setItem(KEY, JSON.stringify(c));
    window.dispatchEvent(new Event(EVT));
  } catch (e) {
    alert("Gagal menyimpan. Mungkin gambar terlalu besar (limit ~5MB).");
    throw e;
  }
}

export function resetContent() {
  localStorage.removeItem(KEY);
  window.dispatchEvent(new Event(EVT));
}

export function useSiteContent(): SiteContent {
  const [c, setC] = useState<SiteContent>(DEFAULTS);
  useEffect(() => {
    setC(loadContent());
    const h = () => setC(loadContent());
    window.addEventListener(EVT, h);
    window.addEventListener("storage", h);
    return () => {
      window.removeEventListener(EVT, h);
      window.removeEventListener("storage", h);
    };
  }, []);
  return c;
}
