import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Sparkles,
  Users,
  Shield,
  ScrollText,
  ChevronRight,
  Flame,
  BookOpen,
  Crown,
  Menu,
  X,
} from "lucide-react";

import crest from "@/assets/crest.png";
import { DEFAULTS, useSiteContent } from "@/lib/site-content";

const CONFIG = DEFAULTS;
const heroBanner = DEFAULTS.heroImage;


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: `${CONFIG.brand} — ${CONFIG.tagline}` },
      {
        name: "description",
        content:
          "Marga Greyrat — komunitas editor anime fantasy bergaya Mushoku Tensei. Berbagi karya, sihir, dan petualangan dalam satu rumah.",
      },
      { property: "og:title", content: `${CONFIG.brand} — ${CONFIG.tagline}` },
      { property: "og:description", content: CONFIG.hero.subtitle },
      { property: "og:image", content: heroBanner },
    ],
  }),
  component: Index,
});

const NAV = [
  { id: "about", label: "Marga" },
  { id: "gallery", label: "Galeri" },
  { id: "rules", label: "Hukum" },
  { id: "leaders", label: "Tetua" },
  { id: "join", label: "Gabung" },
];

function Embers() {
  // Floating mana particles
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      {Array.from({ length: 18 }).map((_, i) => (
        <span
          key={i}
          className="absolute bottom-0 h-1.5 w-1.5 rounded-full bg-primary/60 blur-[1px] animate-ember"
          style={{
            left: `${(i * 53) % 100}%`,
            animationDelay: `${(i % 7) * 0.7}s`,
            animationDuration: `${5 + (i % 4)}s`,
          }}
        />
      ))}
    </div>
  );
}

function Index() {
  const C = useSiteContent();
  const heroBanner = C.heroImage;
  const gallery2 = C.aboutImage;
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <main className="min-h-screen text-foreground antialiased">
      {/* ============ NAV ============ */}
      <header
        className={
          "fixed top-0 inset-x-0 z-40 transition-all duration-300 " +
          (scrolled
            ? "backdrop-blur-xl bg-background/75 border-b border-border"
            : "bg-transparent")
        }
      >
        <div className="mx-auto max-w-7xl px-5 h-16 flex items-center justify-between">
          <a href="#top" className="flex items-center gap-3">
            <img src={crest} alt="" className="h-9 w-9 drop-shadow-[0_0_10px_oklch(0.78_0.18_78/0.5)]" />
            <div className="leading-tight">
              <div className="font-display font-bold text-base tracking-wider text-gradient-gold">
                {C.brand.toUpperCase()}
              </div>
              <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
                {C.tagline}
              </div>
            </div>
          </a>

          <nav className="hidden md:flex items-center gap-8 text-sm">
            {NAV.map((n) => (
              <a
                key={n.id}
                href={`#${n.id}`}
                className="text-muted-foreground hover:text-primary transition relative group"
              >
                {n.label}
                <span className="absolute -bottom-1 left-0 h-px w-0 bg-primary transition-all group-hover:w-full" />
              </a>
            ))}
          </nav>

          <a
            href={C.joinUrl}
            target="_blank"
            rel="noreferrer"
            className="hidden md:inline-flex items-center gap-2 rounded-full px-5 py-2 text-sm font-medium bg-gradient-to-br from-primary to-yellow-600 text-primary-foreground hover:opacity-90 transition glow-gold"
          >
            <Sparkles className="h-4 w-4" /> Gabung
          </a>

          <button
            className="md:hidden p-2 text-foreground"
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle menu"
          >
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile menu */}
        {open && (
          <div className="md:hidden border-t border-border bg-background/95 backdrop-blur-xl animate-fade-in">
            <div className="px-5 py-4 flex flex-col gap-3">
              {NAV.map((n) => (
                <a
                  key={n.id}
                  href={`#${n.id}`}
                  onClick={() => setOpen(false)}
                  className="py-2 text-foreground/90 hover:text-primary"
                >
                  {n.label}
                </a>
              ))}
              <a
                href={C.joinUrl}
                target="_blank"
                rel="noreferrer"
                className="mt-2 inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 text-sm font-medium bg-gradient-to-br from-primary to-yellow-600 text-primary-foreground"
              >
                <Sparkles className="h-4 w-4" /> Gabung Marga
              </a>
            </div>
          </div>
        )}
      </header>

      {/* ============ HERO ============ */}
      <section id="top" className="relative isolate pt-16">
        <div className="relative h-[92vh] min-h-[620px] w-full overflow-hidden">
          <img
            src={heroBanner}
            alt="Banner kerajaan sihir"
            className="absolute inset-0 h-full w-full object-cover scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/20 via-background/60 to-background" />
          <div className="absolute inset-0 bg-gradient-to-tr from-accent/30 via-transparent to-primary/10 mix-blend-soft-light" />
          <Embers />

          <div className="relative z-10 flex h-full items-center">
            <div className="mx-auto max-w-7xl px-6 w-full">
              <div className="max-w-2xl animate-fade-in">
                <div className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-background/40 backdrop-blur px-3 py-1.5 text-xs uppercase tracking-[0.25em] text-primary">
                  <Flame className="h-3.5 w-3.5" /> {C.hero.eyebrow}
                </div>
                <h1 className="mt-6 font-display text-5xl sm:text-6xl md:text-7xl font-bold leading-[1.05]">
                  <span className="text-foreground">{C.hero.title.split(" ").slice(0, -2).join(" ")} </span>
                  <span className="shimmer-gold">
                    {C.hero.title.split(" ").slice(-2).join(" ")}
                  </span>
                </h1>
                <p className="mt-6 max-w-xl text-lg text-muted-foreground font-body">
                  {C.hero.subtitle}
                </p>
                <div className="mt-10 flex flex-wrap items-center gap-4">
                  <a
                    href={C.joinUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-br from-primary to-yellow-600 px-7 py-3.5 text-sm font-semibold text-primary-foreground glow-gold hover:scale-[1.02] transition"
                  >
                    {C.hero.primaryCta}
                    <ChevronRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
                  </a>
                  <a
                    href="#gallery"
                    className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-background/30 backdrop-blur px-7 py-3.5 text-sm font-semibold text-foreground hover:bg-background/50 transition"
                  >
                    <BookOpen className="h-4 w-4" /> {C.hero.secondaryCta}
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Floating crest */}
          <img
            src={crest}
            alt=""
            className="hidden lg:block absolute right-10 bottom-16 h-72 w-72 opacity-90 animate-float drop-shadow-[0_20px_60px_oklch(0.55_0.22_35/0.5)]"
          />
        </div>
      </section>

      {/* ============ ABOUT / INFO ============ */}
      <section id="about" className="relative py-28 px-5">
        <div className="mx-auto max-w-6xl">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            <div>
              <div className="text-xs uppercase tracking-[0.3em] text-primary mb-4 flex items-center gap-2">
                <span className="h-px w-8 bg-primary/70" /> Tentang
              </div>
              <h2 className="font-display text-4xl md:text-5xl font-bold">
                {C.about.title}
              </h2>
              <p className="mt-6 text-lg text-muted-foreground leading-relaxed font-body">
                {C.about.body}
              </p>
              <div className="mt-10 grid grid-cols-3 gap-4">
                {C.about.stats.map((s) => (
                  <div
                    key={s.label}
                    className="rounded-2xl border border-border bg-card/60 backdrop-blur p-5 text-center"
                  >
                    <div className="font-display text-3xl text-gradient-gold font-bold">
                      {s.value}
                    </div>
                    <div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">
                      {s.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="absolute -inset-6 bg-gradient-to-tr from-accent/30 via-primary/10 to-transparent blur-3xl" />
              <div className="relative rounded-3xl overflow-hidden border border-primary/30 ring-gold">
                <img
                  src={gallery2}
                  alt="Negeri marga"
                  className="aspect-[4/5] w-full object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/10 to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <div className="text-xs uppercase tracking-[0.3em] text-primary">Markas Marga</div>
                  <div className="font-display text-2xl mt-1">Buena Village Hall</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ GALLERY ============ */}
      <section id="gallery" className="relative py-28 px-5">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-accent/5 to-transparent pointer-events-none" />
        <div className="mx-auto max-w-7xl relative">
          <div className="flex items-end justify-between flex-wrap gap-4 mb-12">
            <div>
              <div className="text-xs uppercase tracking-[0.3em] text-primary mb-3 flex items-center gap-2">
                <span className="h-px w-8 bg-primary/70" /> Galeri
              </div>
              <h2 className="font-display text-4xl md:text-5xl font-bold">
                Lembaran Petualangan
              </h2>
            </div>
            <p className="text-muted-foreground max-w-md font-body">
              Kumpulan karya dan momen dari para anggota marga — setiap frame adalah sihir.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {C.gallery.map((g, i) => (
              <article
                key={g.title}
                className="group relative rounded-2xl overflow-hidden border border-border bg-card hover:border-primary/50 transition-all duration-500 hover:-translate-y-1"
                style={{ animationDelay: `${i * 80}ms` }}
              >
                <div className="aspect-[4/5] overflow-hidden">
                  <img
                    src={g.img}
                    alt={g.title}
                    loading="lazy"
                    className="h-full w-full object-cover transition duration-700 group-hover:scale-110"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent opacity-90" />
                <div className="absolute inset-x-0 bottom-0 p-5">
                  <h3 className="font-display text-xl font-semibold">{g.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{g.desc}</p>
                </div>
                <div className="absolute top-3 right-3 h-8 w-8 rounded-full bg-background/70 backdrop-blur border border-primary/30 grid place-items-center opacity-0 group-hover:opacity-100 transition">
                  <Sparkles className="h-3.5 w-3.5 text-primary" />
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ============ RULES ============ */}
      <section id="rules" className="relative py-28 px-5">
        <div className="mx-auto max-w-6xl">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <div className="text-xs uppercase tracking-[0.3em] text-primary mb-3 flex items-center justify-center gap-2">
              <span className="h-px w-8 bg-primary/70" />
              <ScrollText className="h-3.5 w-3.5" />
              <span className="h-px w-8 bg-primary/70" />
            </div>
            <h2 className="font-display text-4xl md:text-5xl font-bold">
              Hukum Marga
            </h2>
            <p className="mt-4 text-muted-foreground font-body">
              Enam pilar yang menjaga harmoni di rumah kita.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {C.rules.map((r, i) => (
              <div
                key={r.title}
                className="relative rounded-2xl border border-border bg-card/60 backdrop-blur p-6 hover:border-primary/40 transition group overflow-hidden"
              >
                <div className="absolute -top-10 -right-10 h-32 w-32 rounded-full bg-primary/10 blur-2xl group-hover:bg-primary/20 transition" />
                <div className="relative">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-primary/30 to-accent/30 border border-primary/40 grid place-items-center font-display text-primary font-bold">
                      {String(i + 1).padStart(2, "0")}
                    </div>
                    <h3 className="font-display text-lg font-semibold">{r.title}</h3>
                  </div>
                  <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{r.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ LEADERS ============ */}
      <section id="leaders" className="relative py-28 px-5">
        <div className="mx-auto max-w-6xl">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <div className="text-xs uppercase tracking-[0.3em] text-primary mb-3">
              Dewan Marga
            </div>
            <h2 className="font-display text-4xl md:text-5xl font-bold">Tetua &amp; Pemimpin</h2>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {C.leaders.map((l, i) => (
              <div
                key={l.name}
                className="group relative rounded-2xl border border-border bg-gradient-to-b from-card to-card/40 p-6 text-center hover:border-primary/40 transition"
              >
                <div className="relative mx-auto h-24 w-24">
                  <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/40 to-accent/40 blur-xl group-hover:blur-2xl transition" />
                  <div className="relative h-full w-full rounded-full bg-gradient-to-br from-primary/30 to-accent/40 border border-primary/40 grid place-items-center">
                    {i === 0 ? (
                      <Crown className="h-10 w-10 text-primary" />
                    ) : i === 1 ? (
                      <Shield className="h-10 w-10 text-primary" />
                    ) : i === 2 ? (
                      <BookOpen className="h-10 w-10 text-primary" />
                    ) : (
                      <Sparkles className="h-10 w-10 text-primary" />
                    )}
                  </div>
                </div>
                <h3 className="mt-5 font-display text-xl font-bold">{l.name}</h3>
                <div className="text-xs uppercase tracking-[0.2em] text-primary/90 mt-1">
                  {l.role}
                </div>
                <p className="mt-3 text-xs italic text-muted-foreground font-body">
                  &laquo; {l.title} &raquo;
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ JOIN CTA ============ */}
      <section id="join" className="relative px-5 py-28">
        <div className="mx-auto max-w-5xl">
          <div className="relative overflow-hidden rounded-[2rem] border border-primary/40 bg-gradient-to-br from-accent/40 via-background to-background p-10 md:p-16 text-center">
            <div className="absolute inset-0 opacity-30 pointer-events-none">
              <img src={heroBanner} alt="" className="h-full w-full object-cover" loading="lazy" />
              <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/85 to-background" />
            </div>
            <Embers />
            <div className="relative">
              <img
                src={crest}
                alt=""
                className="h-20 w-20 mx-auto animate-float drop-shadow-[0_10px_30px_oklch(0.55_0.22_35/0.6)]"
              />
              <h2 className="mt-6 font-display text-4xl md:text-6xl font-bold">
                Saatnya Mengangkat <span className="shimmer-gold">Tongkatmu</span>
              </h2>
              <p className="mt-5 max-w-xl mx-auto text-muted-foreground font-body text-lg">
                Marga Greyrat menanti satu nama lagi di dalam grimoirnya. Gabung sekarang dan mulai
                petualanganmu bersama keluarga baru.
              </p>
              <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
                <a
                  href={C.joinUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 rounded-full bg-gradient-to-br from-primary to-yellow-600 px-9 py-4 font-semibold text-primary-foreground glow-gold hover:scale-[1.03] transition"
                >
                  <Users className="h-5 w-5" /> Gabung Sekarang
                </a>
                <a
                  href="#about"
                  className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-background/30 backdrop-blur px-9 py-4 font-semibold text-foreground hover:bg-background/50 transition"
                >
                  Pelajari Lagi
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ FOOTER ============ */}
      <footer className="border-t border-border">
        <div className="mx-auto max-w-7xl px-5 py-10 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img src={crest} alt="" className="h-8 w-8" />
            <div className="text-sm">
              <span className="font-display text-gradient-gold font-bold tracking-widest">
                {C.brand.toUpperCase()}
              </span>
              <span className="text-muted-foreground"> · {C.tagline}</span>
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} {C.brand}. Dibangun dengan mana &amp; cinta.
          </p>
        </div>
      </footer>
    </main>
  );
}
