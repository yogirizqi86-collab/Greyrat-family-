import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  DEFAULTS,
  loadContent,
  saveContent,
  resetContent,
  type SiteContent,
} from "@/lib/site-content";
import { Lock, Save, RotateCcw, Upload, LogOut, ArrowLeft, Eye } from "lucide-react";

const ADMIN_PASSWORD = "goy1238904567";
const AUTH_KEY = "marga-admin-auth";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [{ title: "Admin · Marga Greyrat" }, { name: "robots", content: "noindex" }],
  }),
  component: AdminPage,
});

function AdminPage() {
  const [authed, setAuthed] = useState(false);
  const [pwd, setPwd] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {
    if (sessionStorage.getItem(AUTH_KEY) === "1") setAuthed(true);
  }, []);

  if (!authed) {
    return (
      <main className="min-h-screen grid place-items-center px-5">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (pwd === ADMIN_PASSWORD) {
              sessionStorage.setItem(AUTH_KEY, "1");
              setAuthed(true);
            } else setErr("Password salah");
          }}
          className="w-full max-w-sm rounded-2xl border border-primary/40 bg-card/80 backdrop-blur p-8 ring-gold"
        >
          <div className="mx-auto h-14 w-14 rounded-full bg-gradient-to-br from-primary/40 to-accent/40 border border-primary/40 grid place-items-center mb-5">
            <Lock className="h-6 w-6 text-primary" />
          </div>
          <h1 className="font-display text-2xl font-bold text-center">Admin Marga</h1>
          <p className="text-sm text-muted-foreground text-center mt-1">
            Masukkan password untuk mengelola situs
          </p>
          <input
            type="password"
            autoFocus
            value={pwd}
            onChange={(e) => {
              setPwd(e.target.value);
              setErr("");
            }}
            placeholder="••••••••"
            className="mt-6 w-full rounded-xl bg-background border border-border px-4 py-3 text-sm focus:border-primary outline-none"
          />
          {err && <p className="text-xs text-red-400 mt-2">{err}</p>}
          <button
            type="submit"
            className="mt-5 w-full rounded-xl bg-gradient-to-br from-primary to-yellow-600 text-primary-foreground font-semibold py-3 glow-gold"
          >
            Masuk
          </button>
          <Link
            to="/"
            className="mt-4 flex items-center justify-center gap-2 text-xs text-muted-foreground hover:text-primary"
          >
            <ArrowLeft className="h-3 w-3" /> Kembali ke beranda
          </Link>
        </form>
      </main>
    );
  }

  return <AdminEditor onLogout={() => { sessionStorage.removeItem(AUTH_KEY); setAuthed(false); }} />;
}

function AdminEditor({ onLogout }: { onLogout: () => void }) {
  const [data, setData] = useState<SiteContent>(DEFAULTS);
  const [savedAt, setSavedAt] = useState<string>("");

  useEffect(() => {
    setData(loadContent());
  }, []);

  const update = <K extends keyof SiteContent>(key: K, value: SiteContent[K]) =>
    setData((d) => ({ ...d, [key]: value }));

  const handleSave = () => {
    saveContent(data);
    setSavedAt(new Date().toLocaleTimeString());
  };

  const handleReset = () => {
    if (!confirm("Kembalikan SEMUA konten ke default? Perubahanmu akan hilang.")) return;
    resetContent();
    setData(DEFAULTS);
    setSavedAt("");
  };

  const pickImage = (cb: (dataUrl: string) => void) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.onchange = () => {
      const file = input.files?.[0];
      if (!file) return;
      if (file.size > 4 * 1024 * 1024) {
        alert("Gambar terlalu besar. Maks 4MB. Coba kompres dulu.");
        return;
      }
      const r = new FileReader();
      r.onload = () => cb(String(r.result));
      r.readAsDataURL(file);
    };
    input.click();
  };

  return (
    <main className="min-h-screen pb-32">
      {/* Top bar */}
      <header className="sticky top-0 z-30 backdrop-blur-xl bg-background/85 border-b border-border">
        <div className="mx-auto max-w-5xl px-5 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-primary/30 to-accent/40 border border-primary/40 grid place-items-center">
              <Lock className="h-4 w-4 text-primary" />
            </div>
            <div className="leading-tight min-w-0">
              <div className="font-display font-bold text-sm tracking-wider text-gradient-gold truncate">
                ADMIN MARGA
              </div>
              <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                {savedAt ? `Tersimpan ${savedAt}` : "Belum disimpan"}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link to="/" className="hidden sm:inline-flex items-center gap-1.5 text-xs rounded-full border border-border px-3 py-2 hover:border-primary/40">
              <Eye className="h-3.5 w-3.5" /> Lihat situs
            </Link>
            <button onClick={handleReset} className="inline-flex items-center gap-1.5 text-xs rounded-full border border-border px-3 py-2 hover:border-red-400/60 text-muted-foreground hover:text-red-400">
              <RotateCcw className="h-3.5 w-3.5" /> Reset
            </button>
            <button onClick={handleSave} className="inline-flex items-center gap-1.5 text-xs rounded-full bg-gradient-to-br from-primary to-yellow-600 text-primary-foreground font-semibold px-4 py-2 glow-gold">
              <Save className="h-3.5 w-3.5" /> Simpan
            </button>
            <button onClick={onLogout} className="p-2 text-muted-foreground hover:text-foreground" title="Keluar">
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-3xl px-5 py-8 space-y-10">
        <p className="text-sm text-muted-foreground">
          Semua perubahan disimpan di perangkat ini (browser). Klik <b>Simpan</b> untuk menerapkan.
        </p>

        <Section title="Identitas">
          <Field label="Nama Marga"><Input value={data.brand} onChange={(v) => update("brand", v)} /></Field>
          <Field label="Tagline"><Input value={data.tagline} onChange={(v) => update("tagline", v)} /></Field>
          <Field label="Link Grup (WhatsApp / Discord / Telegram)">
            <Input value={data.joinUrl} onChange={(v) => update("joinUrl", v)} placeholder="https://..." />
          </Field>
        </Section>

        <Section title="Hero / Banner">
          <ImagePicker
            label="Gambar Banner"
            value={data.heroImage}
            onPick={() => pickImage((url) => update("heroImage", url))}
            onUrl={(v) => update("heroImage", v)}
            onClear={() => update("heroImage", DEFAULTS.heroImage)}
          />
          <Field label="Eyebrow (label kecil di atas judul)">
            <Input value={data.hero.eyebrow} onChange={(v) => update("hero", { ...data.hero, eyebrow: v })} />
          </Field>
          <Field label="Judul Besar">
            <Input value={data.hero.title} onChange={(v) => update("hero", { ...data.hero, title: v })} />
          </Field>
          <Field label="Subjudul">
            <Textarea value={data.hero.subtitle} onChange={(v) => update("hero", { ...data.hero, subtitle: v })} />
          </Field>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Tombol Utama"><Input value={data.hero.primaryCta} onChange={(v) => update("hero", { ...data.hero, primaryCta: v })} /></Field>
            <Field label="Tombol Kedua"><Input value={data.hero.secondaryCta} onChange={(v) => update("hero", { ...data.hero, secondaryCta: v })} /></Field>
          </div>
        </Section>

        <Section title="Tentang">
          <Field label="Judul"><Input value={data.about.title} onChange={(v) => update("about", { ...data.about, title: v })} /></Field>
          <Field label="Deskripsi"><Textarea rows={5} value={data.about.body} onChange={(v) => update("about", { ...data.about, body: v })} /></Field>
          <ImagePicker
            label="Gambar Samping (About)"
            value={data.aboutImage}
            onPick={() => pickImage((url) => update("aboutImage", url))}
            onUrl={(v) => update("aboutImage", v)}
            onClear={() => update("aboutImage", DEFAULTS.aboutImage)}
          />
          <div className="space-y-3">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Statistik</div>
            {data.about.stats.map((s, i) => (
              <div key={i} className="grid grid-cols-2 gap-3">
                <Input value={s.value} onChange={(v) => {
                  const stats = [...data.about.stats]; stats[i] = { ...s, value: v };
                  update("about", { ...data.about, stats });
                }} placeholder="Angka" />
                <Input value={s.label} onChange={(v) => {
                  const stats = [...data.about.stats]; stats[i] = { ...s, label: v };
                  update("about", { ...data.about, stats });
                }} placeholder="Label" />
              </div>
            ))}
          </div>
        </Section>

        <Section title="Galeri">
          {data.gallery.map((g, i) => (
            <div key={i} className="rounded-xl border border-border p-4 space-y-3">
              <div className="text-xs uppercase tracking-wider text-primary">Galeri #{i + 1}</div>
              <ImagePicker
                label="Gambar"
                value={g.img}
                onPick={() => pickImage((url) => {
                  const gal = [...data.gallery]; gal[i] = { ...g, img: url };
                  update("gallery", gal);
                })}
                onUrl={(v) => { const gal = [...data.gallery]; gal[i] = { ...g, img: v }; update("gallery", gal); }}
                onClear={() => { const gal = [...data.gallery]; gal[i] = { ...g, img: DEFAULTS.gallery[i]?.img ?? "" }; update("gallery", gal); }}
              />
              <Field label="Judul">
                <Input value={g.title} onChange={(v) => { const gal = [...data.gallery]; gal[i] = { ...g, title: v }; update("gallery", gal); }} />
              </Field>
              <Field label="Deskripsi">
                <Input value={g.desc} onChange={(v) => { const gal = [...data.gallery]; gal[i] = { ...g, desc: v }; update("gallery", gal); }} />
              </Field>
            </div>
          ))}
        </Section>

        <Section title="Hukum Marga">
          {data.rules.map((r, i) => (
            <div key={i} className="rounded-xl border border-border p-4 space-y-3">
              <div className="text-xs uppercase tracking-wider text-primary">Aturan #{i + 1}</div>
              <Input value={r.title} onChange={(v) => { const rs = [...data.rules]; rs[i] = { ...r, title: v }; update("rules", rs); }} placeholder="Judul" />
              <Textarea value={r.desc} onChange={(v) => { const rs = [...data.rules]; rs[i] = { ...r, desc: v }; update("rules", rs); }} placeholder="Deskripsi" />
            </div>
          ))}
        </Section>

        <Section title="Tetua & Pemimpin">
          {data.leaders.map((l, i) => (
            <div key={i} className="rounded-xl border border-border p-4 grid sm:grid-cols-3 gap-3">
              <Input value={l.name} onChange={(v) => { const ls = [...data.leaders]; ls[i] = { ...l, name: v }; update("leaders", ls); }} placeholder="Nama" />
              <Input value={l.role} onChange={(v) => { const ls = [...data.leaders]; ls[i] = { ...l, role: v }; update("leaders", ls); }} placeholder="Peran" />
              <Input value={l.title} onChange={(v) => { const ls = [...data.leaders]; ls[i] = { ...l, title: v }; update("leaders", ls); }} placeholder="Gelar" />
            </div>
          ))}
        </Section>

        <div className="flex flex-wrap gap-3 pt-4">
          <button onClick={handleSave} className="inline-flex items-center gap-2 rounded-full bg-gradient-to-br from-primary to-yellow-600 text-primary-foreground font-semibold px-6 py-3 glow-gold">
            <Save className="h-4 w-4" /> Simpan Semua Perubahan
          </button>
          <Link to="/" className="inline-flex items-center gap-2 rounded-full border border-primary/40 px-6 py-3 hover:bg-background/50">
            <Eye className="h-4 w-4" /> Lihat Hasilnya
          </Link>
        </div>
      </div>
    </main>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="space-y-4">
      <h2 className="font-display text-xl font-bold text-gradient-gold">{title}</h2>
      <div className="space-y-4">{children}</div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block space-y-1.5">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}

function Input({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full rounded-lg bg-background border border-border px-3 py-2.5 text-sm focus:border-primary outline-none"
    />
  );
}

function Textarea({ value, onChange, placeholder, rows = 3 }: { value: string; onChange: (v: string) => void; placeholder?: string; rows?: number }) {
  return (
    <textarea
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      rows={rows}
      className="w-full rounded-lg bg-background border border-border px-3 py-2.5 text-sm focus:border-primary outline-none resize-y"
    />
  );
}

function ImagePicker({ label, value, onPick, onUrl, onClear }: { label: string; value: string; onPick: () => void; onUrl: (v: string) => void; onClear: () => void }) {
  return (
    <div className="space-y-2">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="flex gap-3 items-start">
        <div className="h-20 w-20 rounded-lg overflow-hidden border border-border bg-card shrink-0">
          {value ? <img src={value} alt="" className="h-full w-full object-cover" /> : null}
        </div>
        <div className="flex-1 space-y-2">
          <div className="flex gap-2 flex-wrap">
            <button type="button" onClick={onPick} className="inline-flex items-center gap-1.5 text-xs rounded-lg border border-primary/40 px-3 py-2 hover:bg-primary/10">
              <Upload className="h-3.5 w-3.5" /> Upload
            </button>
            <button type="button" onClick={onClear} className="text-xs rounded-lg border border-border px-3 py-2 text-muted-foreground hover:border-red-400/40 hover:text-red-400">
              Reset
            </button>
          </div>
          <input
            value={value.startsWith("data:") ? "" : value}
            onChange={(e) => onUrl(e.target.value)}
            placeholder="atau tempel URL gambar..."
            className="w-full rounded-lg bg-background border border-border px-3 py-2 text-xs focus:border-primary outline-none"
          />
        </div>
      </div>
    </div>
  );
}
